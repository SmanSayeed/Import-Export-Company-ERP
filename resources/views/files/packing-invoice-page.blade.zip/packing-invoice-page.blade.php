@extends('master')
@section('sales-contract-section')

 <div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="min-height: 100px; background-image: url('{{asset('frontend')}}/img/theme/vegetable.png'); background-size: cover; background-position: center top;">
      <!-- Mask -->
      <span class="mask bg-gradient-default opacity-8"></span>
      <!-- Header container -->
      
    </div>


     <!-- Page content -->
    <div class="container-fluid mt--7">
      <div class="row">
        
        <div class="col-xl-12 order-xl-1">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Packing & WEIGHT LIST</h3>
                </div>

                <div class="table-responsive">
             
 <!-- ====================================================== -->
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Sales Contract No</th>
      <th scope="col">Importer Name</th>
      <th scope="col">Import Address</th>
      <th scope="col">Import Date</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
      
    <tr>

      <td scope="row">b->id</td>
      <td>bankname</td>
      <td>bankaccount</td>
      <td>bankbranch</td>
      <td>test</td>
      <td>
        <a href="/packing-invoice-view" class="btn btn-primary">View</a>&nbsp;&nbsp;<a href="/packing-invoice-download" class="btn btn-danger" >Download</a>
      </td>
   
    </tr>
     
  </tbody>
</table>

                
 <!-- ====================================================== -->





   </div>
               
              </div>
            </div>
            <div class="card-body">
              

              </div>
            </div>
          </div>
        </div>
      </div>
@endsection