<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	.border-black{
		border:1px solid black;
		height: 15px;
		width: 20px;
	}
	.centering{
		text-align: center;
	}
	body{
		font-size: 12px;
	}

</style>
<body>
<table>
	<tr >
		<td class="border-black" colspan="9"><h3 class="centering">COMMERCIAL INVOICE</h3></td>
	</tr>

	<tr class="border-black">
		<td class="border-black" colspan="9"> 
			<span>SALSE CONTRACT NO:</span><br>
			<span>INVOICE NO:</span><br>
		
			<span>EXP NO:</span><br>
			<span>PACKING LIST NO:</span>

			<span>FINAL DESTINATION:</span><br>
			<span>SALES TERM:</span>

			<span>PAYMENT TERM:</span><br>
			<span>LOADING PORT:</span>

			<span>PORT OF DISCHARGE:</span><br>
			<span>MODE OF CARRYING:</span>

			
			
		</td>
	</tr>

	

	<tr class="border-black">
		<td class="border-black" colspan="5">
			<span>EXPORTER</span><br>
			<span>EXPORTER NAME: </span><br>
			<span>ADDRESS:</span><br>
			<span>CONTACT NO:</span><br>
			<span>EMAIL ADDRESS:</span>
			<span>FACTORY ADDRESS:</span><br>
			<span>BIN NO:</span><br>
			<span>ERC NO:</span><br>

		</td>

		<td class="border-black" colspan="4">
			<span>IMPORTER </span><br>
			<span>IMPORTER NAME</span><br>		
			<span>ADDRESS:</span><br>
			<span>CONTACT NO:</span><br>
			<span>UEN NO:</span><br>
			<span>NOTIFY PARTY:</span><br>
		</td>
	</tr>


	<tr class="border-black">
		<td class="border-black" colspan="4" >
			<span>BENIFICARY BANK</span><br>
			<span>BANK NAME: </span><br>
			<span>ADDRESS/BRANCH:</span><br>
			<span>ACCOUNT NO:</span><br>
		
			<span>SWIFT NO:</span><br>
			

		</td>

		<td class="border-black" colspan="5">
			<span>IMPORTER </span><br>
			<span>BANK NAME: </span><br>
			<span>ADDRESS/BRANCH:</span><br>
			<span>ACCOUNT NO:</span><br>
		
			<span>SWIFT NO:</span><br>
		</td>
	</tr>

	<tbody>
	<tr>
		<td class="border-black" colspan="1" >SL NO</td>
		<td class="border-black" colspan="1">SHIPPING MARKS</td>
		<td class="border-black" colspan="1">HS CODE</td>
		<td class="border-black" colspan="1">DESCRIPTION OF GOODS</td>
		<td class="border-black" colspan="1">PACK SIZE</td>
		<td class="border-black" colspan="1">PCS/CTN</td>
		<td class="border-black " colspan="1">TOTAL CARTON</td>
		<td class="border-black" colspan="1">CFR/FOB VALUE IN US $/CTN</td>
		<td class="border-black" colspan="1">TOTAL CFR/FOB VALUE IN US $</td>

	</tr>
	<tr>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		

	</tr>
	<tr>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		

	</tr>
	<tr>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		

	</tr>
	<tr>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		

	</tr>
	<tr>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		<td class="border-black"></td>
		

	</tr>
		<tr>
		<td class="border-black" colspan="8">FREIGHT CHARGR:</td>
		<td class="border-black"></td>
		
		

	</tr>
		<tr>
		<td class="border-black" colspan="8">TOTAL CFR/FOB VALUE</td>
		<td class="border-black"></td>
		
		

	</tr>
		<tr>
		<td class="border-black" colspan="8">TOTAL AMOUNT IN WORD</td>
		<td class="border-black"></td>
		
		

	</tr>
		<tr>
		<td class="border-black" colspan="8">OTHER INFORMATION</td>
		<td class="border-black"></td>
		
		

	</tr>

	</tbody>


</table>


</body>
</html>