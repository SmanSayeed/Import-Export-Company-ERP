<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Commercial_invoice extends Model
{
    //
}
